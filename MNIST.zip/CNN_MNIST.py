#!/usr/bin/env python
# coding: utf-8

# In[2]:


pip install tensorflow


# In[34]:


import tensorflow as tf
import matplotlib.pyplot as plt
from tensorflow import keras
import numpy as np


# In[5]:


pip install keras


# In[4]:


from keras.datasets import mnist
data = mnist.load_data()


# In[5]:


(train_x, train_y), (test_x, test_y) = keras.datasets.mnist.load_data()
train_x = train_x / 255.0
test_x = test_x / 255.0
train_x = tf.expand_dims(train_x, 3)
test_x = tf.expand_dims(test_x, 3)
val_x = train_x[:5000]
val_y = train_y[:5000]


# In[6]:


lenet_5_model = keras.models.Sequential([
    keras.layers.Conv2D(6, kernel_size=5, strides=1,  activation='tanh', input_shape=train_x[0].shape, padding='same'), #C1
    keras.layers.AveragePooling2D(), #S2
    keras.layers.Conv2D(16, kernel_size=5, strides=1, activation='tanh', padding='valid'), #C3
    keras.layers.AveragePooling2D(), #S4
    keras.layers.Flatten(), #Flatten
    keras.layers.Dense(120, activation='tanh'), #C5
    keras.layers.Dense(84, activation='tanh'), #F6
    keras.layers.Dense(10, activation='softmax') #Output layer
])


# In[8]:


lenet_5_model.compile(optimizer='adam', loss=keras.losses.sparse_categorical_crossentropy, metrics=['accuracy'])


# In[31]:


lenet_5_model.summary()


# In[36]:


result=lenet_5_model.fit(train_x, train_y, epochs=5, validation_data=(val_x, val_y))


# In[37]:


lenet_5_model.evaluate(test_x, test_y)


# In[43]:


# plot loss
plt.subplot(2, 1, 1)
plt.title('Cross Entropy Loss')
plt.plot(result.history['loss'], color='blue', label='train')
plt.plot(result.history['val_loss'], color='orange', label='test')



# plot accuracy
plt.subplot(2, 1, 2)
plt.title('Classification Accuracy')
plt.plot(result.history['accuracy'], color='blue', label='train')
plt.plot(result.history['val_accuracy'], color='orange', label='test')
plt.subplots_adjust(wspace=0.4, hspace=0.4) 
plt.show()


# In[12]:


get_ipython().run_line_magic('matplotlib', 'inline')
image_index = 7777
print(test_y[image_index])
plt.imshow(test_x[image_index], cmap='Greys')


# In[18]:


from tensorflow.python.ops.numpy_ops import np_config
np_config.enable_numpy_behavior()
pred = lenet_5_model.predict(test_x[image_index].reshape(1, 28, 28, 1))
print(pred.argmax())


# In[30]:


from keras.preprocessing.image import load_img
from keras.preprocessing.image import img_to_array
img_path='C:/Users/reliance/Downloads/test_image_7.jpg'
my_img=load_img(img_path, target_size=(28,28), grayscale=True)
#image convert to array
my_img=img_to_array(my_img)
my_img=my_img.reshape(1, 28, 28, 1)
#pixel prep.
my_img=my_img.astype('float32')
my_img=my_img/255.0
pred = lenet_5_model.predict(my_img)
print(pred.argmax())


# In[ ]:




